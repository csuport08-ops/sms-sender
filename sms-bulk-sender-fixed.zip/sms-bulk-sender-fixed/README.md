# Bulk SMS Sender (Textbelt)

Send SMS messages to multiple recipients using the [Textbelt API](https://textbelt.com/).

## How to Deploy on Render

1. Upload this project to a GitHub repo
2. Create a new Web Service at [https://render.com](https://render.com)
3. Connect your repo
4. Set Environment Variable:
   - TEXTBELT_API_KEY=your_actual_key
5. Build Command: npm install
6. Start Command: npm start
