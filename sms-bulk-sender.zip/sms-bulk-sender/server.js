const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

app.post('/send-sms', async (req, res) => {
  const { phoneNumbers, message } = req.body;
  const apiKey = process.env.TEXTBELT_API_KEY;

  if (!Array.isArray(phoneNumbers) || !message) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  const results = [];

  for (const number of phoneNumbers) {
    try {
      const response = await axios.post('https://textbelt.com/text', {
        phone: number,
        message: message,
        key: apiKey,
      });
      results.push({ number, success: response.data.success });
    } catch (err) {
      results.push({ number, success: false, error: err.message });
    }
  }

  res.json({ results });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
