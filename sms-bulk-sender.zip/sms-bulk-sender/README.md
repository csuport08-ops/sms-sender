# Bulk SMS Sender (Textbelt)

Send SMS messages to multiple recipients using the [Textbelt API](https://textbelt.com/).

## 🚀 How to Run

1. Clone this repo
2. Run `npm install`
3. Create a `.env` file with your API key:
   ```
   TEXTBELT_API_KEY=your_real_key_here
   ```
4. Run `npm start`
5. Open [http://localhost:3000](http://localhost:3000)

## ⚠️ Warning

Never expose your API key in a public repo!
